<?php $__env->startSection('content'); ?>
    <main class="main">

        <!-- Appointment Section -->
        <section id="appointment" class="appointment section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>History</h2>
                <p>Riwayat Pemeriksaan</p>
            </div><!-- End Section Title -->

            <div class="container">

                <?php if(session('success')): ?>
                    <div role="alert" class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="text-center mb-3">
                                    <h3>Profile Pasien</h3>
                                </div>
                                <div class="row">
                                    <div class="col-6">Nama Pasien</div>
                                    <div class="col-6">: <?php echo e($user->name); ?></div>
                                    <div class="col-6">Email</div>
                                    <div class="col-6">: <?php echo e($user->email); ?></div>
                                    <div class="col-6">Phone</div>
                                    <div class="col-6">: <?php echo e($user->phone); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="text-center mb-3">
                                    <h3>Detail Lainya</h3>
                                </div>
                                <div class="row">
                                    <div class="col-6">No.RM</div>
                                    <div class="col-6">: <?php echo e($user->rm); ?></div>
                                    <div class="col-6">Alamat</div>
                                    <div class="col-6">: <?php echo e($user->address); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-header">
                        <div class="card-title">Riwayat Pemeriksaan</div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 10px">ID</th>
                                    <th>Dokter</th>
                                    <th>Keluhan</th>
                                    <th>Catatan</th>
                                    <th>Obat</th>
                                    <th>Status</th>
                                    <th>Tanggal Periksa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $checkups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($checkup->id); ?></td>
                                        <td><?php echo e($checkup->schedule->user->name); ?></td>
                                        <td><?php echo e($checkup->complaint); ?></td>
                                        <td><?php echo e($checkup->note); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $checkup->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <h6><span class="badge text-bg-secondary"><?php echo e($detail->medicine->name); ?> - <?php echo e($detail->qty); ?> <?php echo e($detail->medicine->unit); ?> - <?php echo e($detail->application); ?></span></h6>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($checkup->checkup_status()); ?></td>
                                        <td><?php echo e(tglwaktu($checkup->created_at)); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <?php echo e($checkups->links('admin.layouts.paginate')); ?>

                    </div>

                </div>
            </div>

        </section><!-- /Appointment Section -->

    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\rekam-medis-master\resources\views/site/history.blade.php ENDPATH**/ ?>