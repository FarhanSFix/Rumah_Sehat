<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; {{date('Y') != '2024' ? '2024-'.date('Y') : date('Y')}} <a href="{{config('app.url')}}">{{config('app.name')}}</a>.</strong> All rights reserved.
</footer>